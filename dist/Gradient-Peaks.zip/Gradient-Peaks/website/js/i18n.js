/**
 * i18n.js — interface language.
 *
 * One codebase, two languages. Static markup is translated by walking
 * `data-i18n` attributes; anything the program composes at runtime goes through
 * `t()`. Switching language never rebuilds the terrain — it only repaints text.
 *
 * The language is taken from ?lang= in the address, then from what the user
 * last chose, then from the browser's own setting. A teacher can therefore send
 * students a link ending in ?lang=es and be sure of what they will see.
 */

export const LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'es', label: 'Español' },
];

const STRINGS = {
  en: {
    'meta.title': 'Gradient Peaks — walk on the graph of f(x,y)',
    'meta.labtitle': 'Gradient Peaks Lab — the surface and its map, side by side',
    'meta.labdesc': 'The same 3D sandbox with a flat map panel beside the scene: the domain from above, the same level curves in the same colours, and the explorer as a dot.',
    'meta.description': 'A light 3D sandbox for exploring surface plots, level curves, partial derivatives, gradients and constrained maxima of functions of two variables.',

    'panel.hide': 'Hide panel (Tab)',
    'panel.show': 'Show panel (Tab)',

    'sec.function': 'Function',
    'surf.kind': 'Kind of surface',
    'surf.graph': 'Graph — z = f(x, y)',
    'surf.implicit': 'Implicit — F(x, y, z) = 0',
    'surf.parametric': 'Parametric — r(u, v)',
    'surf.flabel': 'F(x, y, z) =',
    'surf.note': 'This surface is not the graph of a function, so there is no height to read level curves off. Everything else applies, and applies in the surface’s own terms: walk on it, and the Derivatives section gives you the geodesic circle, the coordinate directions of whichever grid is on, your velocity and the tangent plane. Click anywhere on the surface to put the explorer there, then press 1 or 2.',
    'fn.label': 'f(x, y) =',
    'fn.examples': '— examples —',
    'fn.cobb05': 'Cobb–Douglas  (x·y)^0.5',
    'fn.cobb37': 'Cobb–Douglas  x^0.3·y^0.7',
    'fn.paraboloid': 'Paraboloid  1 − x² − y²',
    'fn.saddle': 'Saddle  x² − y²',
    'fn.eggcarton': 'Egg carton  sin(3x)·cos(3y)/2',
    'fn.twopeaks': 'Two peaks (Gaussians)',
    'fn.hills': 'Rolling hills',
    'fn.cone': 'Cone  1 − √(x²+y²)',
    'fn.rosenbrock': 'Rosenbrock (try maximising!)',
    'fn.xyexp': 'x·y·e^−(x²+y²)',
    'fn.crochet': 'Crochet hyperbolic ball (Nash–Kuiper, C¹)',
    'fn.elias': 'Mount Saint Elias (real terrain, AK/Yukon)',
    'fn.eliasnote': 'Real elevation data: the 40 km around Mount Saint Elias (Was’eitushaa, Boundary Peak 186, 5 489 m), from the USGS and Canadian national elevation models, sampled every 150 m and carried inside this file. Coordinates are km east and north of the summit; heights are km, so the HUD reads in real kilometres. The feasible set is Alaska: locally the 1903 boundary is a straight line — a linear constraint, exactly like a budget line — and it passes about 470 m north-west of the summit, leaving the peak in Canada. So the highest point of the United States side cannot be the summit: press O and the optimiser finds it, pinned to the line where the level curve is tangent to the frontier — a Lagrange condition you can walk to. The relief is real — 5.4 km over a 40 km window — so the mountain is honestly gentle at true scale; stretch the z-axis dial to exaggerate it the way an atlas does. The window does not follow the explorer here, because the survey has edges. One more honesty: what you walk on is not the raw survey grid but an infinitely differentiable approximation of it — a two-dimensional Fourier (cosine) series fitted to the data, staying within about 90 m of it on average. Interpolating every sample would make hundreds of pixel-sized relative maxima and a function differentiable only once; the smooth fit keeps the massif’s dozen real shoulders and gives every tool an exact object — gradients that vary smoothly, level curves that are differentiable curves, a true tangent plane at every point, geodesics of a smooth metric. The crags, snow and ice you see are decoration standing on the surface: mathematically, this mountain is as smooth as any formula above.',
    'fn.crochetnote': "A once-differentiable, nowhere-twice-differentiable embedding of a piece of the hyperbolic disk of radius a = 1/√3 — the mathematical model behind a real crochet hyperbolic surface. Hilbert's theorem rules out a smooth (C²) isometric copy of any unbounded piece of the hyperbolic plane in ordinary space; Nash and Kuiper showed C¹ has no such obstruction. This is the single-wave case of their construction: it matches the true metric only to fourth order in the radius, and the mismatch shows as the one ripple you see. The domain and feasible set are set to the disk ρ ≤ a this construction is valid on.",

    'shape.named': 'Named surface',
    'shape.custom': '— custom (type below) —',
    'shape.sphere': 'Sphere — radius a',
    'shape.torus': 'Torus — radii a, b',
    'shape.pseudo': 'Pseudosphere — radius a',
    'shape.hyper1': 'Hyperboloid, one sheet — a, b',
    'shape.catenoid': 'Catenoid — waist a',
    'shape.helicoid': 'Helicoid — radius a, pitch b',
    'shape.mobius': 'Möbius strip — radius a, width b',
    'shape.klein': 'Klein bottle (3D immersion) — a',
    'shape.cross': 'Cross-cap — a',
    'shape.pa': 'a', 'shape.pb': 'b',
    'shape.radius': 'radius a', 'shape.tube': 'tube radius b',
    'shape.pitch': 'pitch b', 'shape.width': 'half-width b', 'shape.waist': 'waist a',
    'shape.orientable': 'Orientable: it has two sides, and the inside / outside toggle means something.',
    'shape.nonorientable': 'Not orientable: it has only one side. Walk a full lap and the explorer comes back upside down — the inside / outside toggle only chooses where to start.',
    'shape.immersion': 'This is a 3-dimensional immersion, so the surface passes through itself. The true embedding needs a fourth dimension; walking through the intersection is the price of drawing it here.',
    'shape.mobiusflag': 'The colour runs one lap: white where the explorer starts, deepest blue at the far side, white again on return. The flag at the start runs through the strip — blue pennant on the starting side, white on the other — so after one full lap you stand on the same white ground, facing the white flag.',
    'orient.inside': 'Walk on the inside',
    'orient.up': 'Which way is up',
    'orient.normal': 'Normal to the tangent plane',
    'orient.z': 'World z (the usual vertical)',
    'orient.x': 'World x',
    'orient.y': 'World y',
    'orient.note': 'Click the surface to land the explorer on it. Walking keeps them upright with respect to the surface: on a sphere that is a planet, on a Möbius strip one lap brings them back upside down, which is what non-orientable means. In third person the camera holds a fixed height and circles, so the movement reads in three dimensions.',
    'orient.click': 'Click the surface to place the explorer',
    'cons.mode': 'Consumer problem',
    'cons.utility': 'Utility function',
    'cons.cobb': 'Cobb–Douglas  x^a · y^(1−a)',
    'cons.ces': 'CES  (x^r + y^r)^(1/r)',
    'cons.subs': 'Perfect substitutes  a·x + (1−a)·y',
    'cons.quasi': 'Quasi-linear  a·ln x + y',
    'cons.alpha': 'Share a',
    'cons.rho': 'Substitution r',
    'cons.px': 'price of x',
    'cons.py': 'price of y',
    'cons.inc': 'income',
    'cons.note': 'The feasible set becomes the budget set p<sub>x</sub>·x + p<sub>y</sub>·y ≤ m with x, y ≥ 0, the domain is framed on it, and the vocabulary on screen changes: level curves are indifference curves, and RMS is the marginal rate of substitution. Turn on the optimum to find the consumer’s choice.',
    'cons.contours': 'Indifference curves',
    'cons.curveshow': 'Indifference curve you are standing on',
    'cons.seccurve': 'The indifference curve under your feet',
    'cons.mrs': 'MRS',
    'cons.mrshelp': 'Marginal rate of substitution — |∂u/∂x ÷ ∂u/∂y|, the absolute slope of the indifference curve through the bundle you are standing on. At the optimum it equals the price ratio p_x / p_y.',
    'cons.budget': 'Budget set',
    'lab.sec': 'Flat map panel',
    'lab.link': 'Open the Lab — the same program with a flat map panel beside the scene',
    'lab.linkback': 'Back to the classic layout',
    'lab.mode': 'What the panel shows',
    'lab.ramp': 'Heat map on the level-curve ramp',
    'lab.heat': 'Classical heat map',
    'lab.down': 'Looking straight down at the surface',
    'lab.off': 'Nothing — hide the panel',
    'lab.opacity': 'Panel opacity',
    'lab.size': 'Panel size',
    'lab.full': 'Full screen',
    'lab.projlabel': 'the (x, y) plane',
    'lab.note': 'The panel is the picture your textbook draws: the domain seen from above, with the same level curves in the same colours, the same tangent line, and the explorer as a dot. Everything on it is the same state as the scene behind — walk in the 3D view and the dot walks on the map.',
    'sec.domain': 'Domain',
    'dom.xmin': 'x min', 'dom.xmax': 'x max', 'dom.ymin': 'y min', 'dom.ymax': 'y max',
    'dom.res': 'Mesh resolution',
    'dom.axes': 'Axis scale',
    'dom.sx': 'x axis', 'dom.sy': 'y axis', 'dom.sz': 'z axis (steepness)',
    'dom.isotropic': 'Reset to equal axes',
    'dom.axesnote': 'All three at 1 is ordinary Cartesian space, where the unit sphere is round. Stretching an axis changes the picture only — every number reported stays the true value.',
    'dom.follow': 'The window follows the explorer',
    'dom.followg': 'step G (x)',
    'dom.followh': 'step H (y)',
    'dom.follownote': 'Reaching an edge slides that axis along by G (or H) times its own width, in the direction you were walking, and the terrain is rebuilt around the new window. The width never changes, so the scale — and every reading taken against the 1.80 m explorer — survives the move. It is left off in the consumer problem, where the domain is not a window but the set of bundles that exist.',
    'dom.rebuild': 'Rebuild terrain',

    'sec.feasible': 'Feasible set',
    'feas.label': 'constraints',
    'feas.examples': '— examples —',
    'feas.triangle': 'Triangle  x,y ≥ 0, x+y ≤ 2',
    'feas.disc': 'Disc  x² + y² ≤ 1',
    'feas.rect': 'Rectangle',
    'feas.two': 'Two budget lines',
    'feas.curved': 'x·y ≥ 0.3, x+y ≤ 2.5',
    'feas.walls': 'Show frontier walls',
    'feas.isolate': 'Make the outside translucent',

    'sec.map': 'Map & terrain',
    'sec.grid': 'Grid on the surface',
    'sec.scale': 'Explorer scale',
    'map.contours': 'Level curves',
    'map.cstep': 'Contour interval Δz (blank = automatic)',
    'map.cwidth': 'Path width',
    'map.cwidthnote': 'Measured in explorer heights, so the paths stay walkable at every scale: shrink the explorer and the contours narrow with them. Two heights is the same width as a grid square’s side.',
    'map.heightcol': 'Colour the surface by height',
    'map.world': 'Paint the world map on it',
    'map.worldnote': 'Longitude across, latitude up — the flattest map there is — laid on the parameter rectangle, or on the domain of a graph, or on longitude and latitude about the centre of an implicit surface. On the standard sphere it becomes the globe it was traced from and the flat map’s distortion visibly undoes itself. On anything else it distorts in that surface’s own way. No sheet of paper can carry a sphere without stretching it: that is Gauss’s Theorema Egregium, and this is what it looks like.',
    'map.grid': 'Coordinate grid on the surface',
    'map.gridnote': 'Every square is two explorers on a side, measured along the surface, in all three regimes — so the mesh is a ruler and not decoration. On a graph it is the grid of the (x, y) plane lifted onto the surface; on a parametric surface, its parameter lines; on an implicit one, where the surface cuts the coordinate planes. It is drawn on both sides, so it stays readable from inside.',
    'map.geogrid': 'Build it from geodesics instead',
    'map.geonote': 'The geodesic grid is built only from straightest paths and arc length, so its squares really are that size wherever they sit — which the other two cannot promise, since their spacing comes from how the surface was written down rather than from the surface. Where the squares stop meeting at right angles, that is the curvature.',
    'map.gridside': 'squares of {n} explorer heights a side{m}',
    'map.gridgeo': 'geodesic squares of {n} explorer heights of arc length a side',
    'map.clamped': 'interval widened to keep the count manageable',
    'map.decor': 'Vegetation, rocks & snow',
    'map.water': 'Water in the depressions',
    'map.density': 'Decoration density',
    'map.decorsize': 'Size of the trees',
    'map.decorsizenote': 'At 1× a tree is about four times the explorer’s height, which is what a tree is. On a small sphere that makes for a very tall forest, so this is here to be turned down.',
    'map.decormatch': 'Vegetation scales with the explorer',
    'map.decormatchnote': "On by default: shrink or grow the explorer with the scale dial and every tree, rock and blade of grass shrinks or grows by exactly the same factor, so the picture you see keeps the same proportions at any scale. The dial above still multiplies on top of that. Turn this off to hold the vegetation at a fixed size while the explorer's own scale changes underneath it.",
    'map.shadows': 'Shadows (costs performance)',

    'sec.deriv': 'Derivatives',
    'deriv.disc': 'Highlight neighbourhood',
    'deriv.radius': 'Radius',
    'deriv.dx': '∂f/∂x arrow',
    'deriv.dy': '∂f/∂y arrow',
    'deriv.grad': 'Gradient ∇f',
    'deriv.dir': 'Directional derivative',
    'deriv.dirnote': 'Move the mouse to swing <b>u</b> around the rim; hold the <b>right</b> mouse button to look around instead. Walking stays free.',
    'deriv.arcnote': 'The radius is arc length — the distance actually walked over the surface, not on the flat floor underneath. On a steep slope the patch therefore covers less of the (x, y) plane, and the rim is no longer a circle.',
    'deriv.tangent': 'Tangent plane',
    'deriv.geodisc': 'Measure it with geodesics instead',
    'deriv.geodiscnote': 'The rim becomes the set of points a walk of that length away along the straightest path, rather than along a fixed compass bearing. The two agree on a plane and nowhere else — and how far apart they get is the curvature.',
    'deriv.geocircle': 'Geodesic circle around you',
    'deriv.axisa': 'First coordinate direction',
    'deriv.axisb': 'Second coordinate direction',
    'deriv.velocity': 'Velocity vector',
    'deriv.tangentp': 'Tangent plane at your feet',
    'deriv.intrinsic': 'There is no f here, so there is no function to take a partial derivative of — what is left are the objects of the surface itself. The neighbourhood is the geodesic circle: everywhere you can reach by walking that far along a straightest path. The two arrows are the coordinate directions of whichever grid is switched on, tangent to the surface. The velocity is the direction you are actually travelling.',

    'sec.curve': 'The curve under your feet',
    'curve.show': 'Level curve you are standing on',
    'curve.tangent': 'Tangent line to that curve',
    'curve.note': 'Both are painted on the surface itself and follow the explorer continuously. The tangent is the tangent direction pushed back down onto the surface, so it hugs the ground; it parts from the level curve only at second order, and shrinking the explorer closes the gap. Each curve takes its colour from its own height on the ramp.',

    'sec.zoom': 'Tangent plane',
    'zoom.scale': 'Explorer scale',
    'zoom.note': 'Turn this on and take the explorer scale down a decade or two: a differentiable surface becomes indistinguishable from its tangent plane, which is what differentiable means.',
    'zoom.scalenote': 'Slide right and the explorer shrinks, down to 0.18 mm; slide left and they grow to a hundred times life size. The mouse wheel with \u2318/\u229e or Alt held does the same thing. Everything measured against them — the neighbourhood, the arrows, the grid squares — changes with them, which is what makes this a ruler and not a camera control.',

    'sec.opt': 'Optimisation',
    'opt.show': 'Show optimum',
    'opt.idle': 'Maximise f over the feasible set.',
    'opt.goto': 'Teleport to the optimum',
    'opt.none': 'No feasible point found on this domain.',
    'opt.max': 'max f =',
    'opt.at': 'at (x, y) =',
    'opt.on': 'on the',
    'opt.interior': 'interior of the feasible set',
    'opt.boundary': 'boundary of the feasible set',
    'opt.domain': 'domain',
    'opt.gradthere': '‖∇f‖ there =',
    'opt.pill': 'max {v} at ({x}, {y})',

    'sec.view': 'View',
    'view.first': 'First person',
    'view.third': 'Third person',
    'view.drone': 'Drone',
    'view.dronecam': 'Drone camera',
    'view.dronefirst': 'First person — from the drone',
    'view.dronethird': 'Third person — behind the drone',
    'view.dronenote': 'The drone flies level: W A S D move it over the (x, y) plane, Space and Ctrl set its altitude, and the mouse only aims the camera. The beam under it drops straight down to the point of the domain you are above.',
    'view.style': "Explorer's look",
    'view.speed': 'Walking speed',
    'view.padoff': 'No gamepad — press a button on one to wake it up.',
    'view.padon': 'Gamepad: {name}',
    'view.padinvert': "Invert the right stick's up / down",
    'view.padnote': "An Xbox-layout controller works straight away, including on an iPhone or iPad over Bluetooth — no app to install. Left stick walks and strafes, right stick looks and turns. RT sprints, LB and RB take the drone down and up. A steps through the three views, B the neighbourhood, X the grid, Y the world map, Start hides the panel; the D-pad's up and down change the explorer's scale and its left and right the camera zoom. Browsers keep a gamepad hidden until a button on it is pressed, so if the line above says there is none, press one.",
    'view.speednote': 'A multiple of the ordinary walking pace, which is already measured in explorer heights per second — so an explorer a tenth the size still crosses the same ground in the same time. Hold Shift to sprint on top of whatever is set here.',
    'style.explorer': 'Hiker',
    'style.brick': 'Brick minifigure',
    'style.blocky': 'Blocky (pixel style)',
    'style.buddy': 'Round buddy',
    'view.compass': 'Direction indicator',
    'view.compassnote': 'The globe in the top right shows which way you are looking: latitude and longitude around a small figure turned to face the same direction, with the bearing and the elevation underneath. Hold \u2318/\u229e or Alt, or press Esc and move the mouse, and it enlarges.',
    'view.holdkey': 'Key to hold for looking',
    'hold.either': 'Either — Alt/\u2325 or \u2318/\u229e',
    'hold.alt': 'Alt / \u2325 Option only',
    'hold.meta': '\u2318 Command / \u229e Windows only',
    'hold.note': 'Held down, this key turns W A S D and the arrow keys into a look control, and the mouse wheel into the explorer\u2019s size. Note that \u2318+W closes a tab on a Mac and no web page can stop it, and that Windows keeps \u229e+arrows for window snapping — choose Alt / \u2325 above and neither applies.',
    'hold.notealt': 'Held down, this key turns W A S D and the arrow keys into a look control, and the mouse wheel into the explorer\u2019s size. Alt / \u2325 is free with every key on every platform, so nothing here is taken by the operating system first.',
    'view.top': 'Look straight down',
    'view.reset': 'Return to the centre',

    'sec.help': 'Help',
    'help.move': 'Move', 'help.run': 'run', 'help.look': 'look', 'help.mouse': 'mouse',
    'help.keylook': 'Look without the mouse',
    'help.orcmd': 'or \u2318/\u229e',
    'help.zoomcam': 'Camera zoom',
    'help.zoomsize': "explorer\u2019s size",
    'help.wheel': 'wheel',
    'help.updown': 'Drone up/down',
    'help.release': 'Release the mouse', 'help.hide': 'hide this panel',
    'help.modnote': 'The modifier is <b>held</b>, not tapped: the look control lasts exactly as long as the key is down. Any of <kbd>Alt</kbd>/<kbd>\u2325</kbd>, <kbd>\u2318</kbd> or <kbd>\u229e</kbd> will do — but note that on a Mac <kbd>\u2318</kbd>+<kbd>W</kbd> closes the tab and no web page can stop it, so use <kbd>\u2325</kbd> if you want W A S D there; and Windows keeps <kbd>\u229e</kbd>+arrows for itself, so use <kbd>Alt</kbd> or W A S D there.',
    'help.syntax': 'Write functions with <code>+ − * / ^</code>, and <code>sin cos tan exp ln sqrt abs min max hypot gauss</code>. Implicit products work: <code>2x</code>, <code>x y</code>. Constraints combine with <code>&&</code>, <code>||</code>, and chained comparisons like <code>0&lt;=x&lt;=1</code>.',

    'hud.z': 'z = f(x,y)',
    'hud.avg': 'avg',
    'hud.scale11': 'scale 1 : 1',
    'hud.tall': 'explorer {h} m tall',
    'hud.uat': 'u at {deg}°',
    'hud.angle': 'they meet at',
    'hud.noaxis': 'perpendicular to the surface here — no direction to draw',
    'hud.frombase': '{deg} from {a}',
    'hud.undefined': 'undefined',
    'hud.rmshelp': 'RMS — |∂f/∂x ÷ ∂f/∂y|, the absolute slope of the level curve through the point you are standing on.',

    'dial.camhelp': 'Camera zoom — the mouse wheel, or a pinch on the trackpad. Moves the camera closer; the explorer stays exactly the size they were.',
    'dial.camreset': 'Back to the standard camera distance',
    'dial.sizehelp': "The explorer's size — hold ⌘ (⊞ on Windows) or Alt/Option and use the wheel. Shrinking them magnifies the surface, the same as the ruler dial in the panel.",
    'dial.sizereset': 'Back to 1 : 1 — the explorer 1.8 m tall',

    'cc.click': 'Click to look around',
    'cc.esc': 'Esc releases the mouse',
    'loading': 'Building the terrain…',

    'msg.undefinedFrac': 'f is undefined on {pct}% of the domain',
    'msg.emptyFeasible': 'the feasible set is empty here',
    'surf.empty': 'That surface is empty in this box — widen the bounds or check the formula.',
    'err.emptyDomain': 'Domain is empty — check that x max > x min and y max > y min.',
    'err.undefinedEverywhere': 'f(x,y) is undefined everywhere on this domain.',
    'err.at': '(at character {pos})',

    // Parser diagnostics.
    'p.badChar': 'Unexpected character "{c}"',
    'p.unknownFn': 'Unknown function "{name}"',
    'p.missingParen': 'Missing ")"',
    'p.missingBar': 'Missing closing "|"',
    'p.missingCall': 'Missing ")" after {name}(',
    'p.arity': '{name}() takes {want} argument(s), got {got}',
    'p.isFunction': '"{name}" is a function — write {name}(...)',
    'p.unknownName': 'Unknown name "{name}"',
    'p.badOperator': 'Unexpected operator "{op}"',
    'p.eof': 'Unexpected end of expression',
    'p.unexpected': 'Unexpected "{what}"',
    'p.trailing': 'Unexpected trailing input',
    'p.empty': 'Expression is empty',
    'p.notNumber': 'Expression did not produce a number',
  },

  es: {
    'meta.title': 'Gradient Peaks — camine sobre la gráfica de f(x,y)',
    'meta.labtitle': 'Gradient Peaks Lab — la superficie y su mapa, lado a lado',
    'meta.labdesc': 'El mismo laboratorio 3D con un panel de mapa plano junto a la escena: el dominio visto desde arriba, las mismas curvas de nivel en los mismos colores y el explorador como un punto.',
    'meta.description': 'Un entorno 3D ligero para explorar gráficas de superficie, curvas de nivel, derivadas parciales, gradientes y máximos con restricciones de funciones de dos variables.',

    'panel.hide': 'Ocultar el panel (Tab)',
    'panel.show': 'Mostrar el panel (Tab)',

    'sec.function': 'Función',
    'surf.kind': 'Tipo de superficie',
    'surf.graph': 'Gráfica — z = f(x, y)',
    'surf.implicit': 'Implícita — F(x, y, z) = 0',
    'surf.parametric': 'Paramétrica — r(u, v)',
    'surf.flabel': 'F(x, y, z) =',
    'surf.note': 'Esta superficie no es la gráfica de una función, así que no hay altura de la que leer curvas de nivel. Todo lo demás se aplica, y se aplica en los términos de la propia superficie: camine sobre ella y la sección de Derivadas le da el círculo geodésico, las direcciones coordenadas de la rejilla activa, su velocidad y el plano tangente. Haga clic en cualquier punto de la superficie para colocar allí al explorador y pulse 1 o 2.',
    'fn.label': 'f(x, y) =',
    'fn.examples': '— ejemplos —',
    'fn.cobb05': 'Cobb–Douglas  (x·y)^0.5',
    'fn.cobb37': 'Cobb–Douglas  x^0.3·y^0.7',
    'fn.paraboloid': 'Paraboloide  1 − x² − y²',
    'fn.saddle': 'Silla de montar  x² − y²',
    'fn.eggcarton': 'Cartón de huevos  sin(3x)·cos(3y)/2',
    'fn.twopeaks': 'Dos picos (gaussianas)',
    'fn.hills': 'Colinas onduladas',
    'fn.cone': 'Cono  1 − √(x²+y²)',
    'fn.rosenbrock': 'Rosenbrock (¡intente maximizarla!)',
    'fn.xyexp': 'x·y·e^−(x²+y²)',
    'fn.crochet': 'Bola de ganchillo hiperbólica (Nash–Kuiper, C¹)',
    'fn.elias': 'Monte San Elías (terreno real, AK/Yukón)',
    'fn.eliasnote': 'Datos reales de elevación: los 40 km alrededor del Monte San Elías (Was’eitushaa, Pico Fronterizo 186, 5 489 m), de los modelos nacionales de elevación de EE. UU. y Canadá, muestreados cada 150 m y llevados dentro de este archivo. Las coordenadas son km al este y al norte de la cima; las alturas, km, así que el marcador lee kilómetros reales. El conjunto factible es Alaska: localmente la frontera de 1903 es una línea recta —una restricción lineal, exactamente como una recta presupuestaria— y pasa a unos 470 m al noroeste de la cima, dejando el pico en Canadá. Por eso el punto más alto del lado estadounidense no puede ser la cima: pulse O y el optimizador lo encuentra, clavado en la línea donde la curva de nivel es tangente a la frontera — una condición de Lagrange a la que se puede caminar. El relieve es real —5,4 km en una ventana de 40 km—, así que a escala verdadera la montaña es honestamente suave; estire el mando del eje z para exagerarla como hace un atlas. Aquí la ventana no sigue al explorador, porque el levantamiento topográfico tiene bordes. Una honestidad más: lo que se pisa no es la malla cruda del levantamiento sino una aproximación infinitamente diferenciable de ella — una serie de Fourier (de cosenos) en dos dimensiones ajustada a los datos, que se mantiene en promedio a unos 90 m de ellos. Interpolar cada muestra crearía cientos de máximos relativos del tamaño de un píxel y una función diferenciable una sola vez; el ajuste suave conserva la docena de hombros reales del macizo y da a cada herramienta un objeto exacto: gradientes que varían con suavidad, curvas de nivel que son curvas diferenciables, un plano tangente verdadero en cada punto, geodésicas de una métrica suave. Los riscos, la nieve y el hielo que se ven son decoración apoyada sobre la superficie: matemáticamente, esta montaña es tan suave como cualquier fórmula de las de arriba.',
    'fn.crochetnote': 'Una inmersión diferenciable una vez pero en ningún punto dos veces, de un trozo del disco hiperbólico de radio a = 1/√3: el modelo matemático detrás de una verdadera superficie hiperbólica de ganchillo. El teorema de Hilbert descarta una copia isométrica suave (C²) de cualquier trozo no acotado del plano hiperbólico en el espacio ordinario; Nash y Kuiper mostraron que en C¹ no existe tal obstrucción. Este es el caso de una sola onda de su construcción: solo iguala la métrica verdadera hasta cuarto orden en el radio, y ese desajuste es el único rizo que se ve. El dominio y el conjunto factible quedan fijados al disco ρ ≤ a en el que esta construcción es válida.',

    'cons.mode': 'Problema del consumidor',
    'shape.named': 'Superficie con nombre',
    'shape.custom': '— a la medida (escríbala abajo) —',
    'shape.sphere': 'Esfera — radio a',
    'shape.torus': 'Toro — radios a, b',
    'shape.pseudo': 'Pseudoesfera — radio a',
    'shape.hyper1': 'Hiperboloide de una hoja — a, b',
    'shape.catenoid': 'Catenoide — cintura a',
    'shape.helicoid': 'Helicoide — radio a, paso b',
    'shape.mobius': 'Banda de Möbius — radio a, ancho b',
    'shape.klein': 'Botella de Klein (inmersión 3D) — a',
    'shape.cross': 'Cross-cap — a',
    'shape.pa': 'a', 'shape.pb': 'b',
    'shape.radius': 'radio a', 'shape.tube': 'radio del tubo b',
    'shape.pitch': 'paso b', 'shape.width': 'semiancho b', 'shape.waist': 'cintura a',
    'shape.orientable': 'Orientable: tiene dos caras, y la opción interior / exterior significa algo.',
    'shape.nonorientable': 'No orientable: tiene una sola cara. Dé una vuelta completa y el explorador regresa de cabeza: eso es justamente ser no orientable. La opción interior / exterior solo elige por dónde empezar.',
    'shape.immersion': 'Esta es una inmersión en tres dimensiones, así que la superficie se atraviesa a sí misma. El encaje verdadero necesita una cuarta dimensión; caminar a través de la intersección es el precio de dibujarla aquí.',
    'shape.mobiusflag': 'El color recorre una vuelta: blanco donde empieza el explorador, azul más profundo en el lado opuesto y blanco de nuevo al regresar. La bandera del inicio atraviesa la cinta — banderín azul en el lado de partida, blanco en el otro —, de modo que tras una vuelta completa se pisa el mismo suelo blanco, pero frente a la bandera blanca.',
    'orient.inside': 'Caminar por dentro',
    'orient.up': 'Hacia dónde queda arriba',
    'orient.normal': 'Normal al plano tangente',
    'orient.z': 'z del mundo (la vertical de siempre)',
    'orient.x': 'x del mundo',
    'orient.y': 'y del mundo',
    'orient.note': 'Haga clic sobre la superficie para dejar allí al explorador. Al caminar se mantiene erguido respecto de la superficie: en una esfera eso es un planeta; en una banda de Möbius, una vuelta completa lo devuelve de cabeza, que es lo que significa no ser orientable. En tercera persona la cámara mantiene una altura fija y gira alrededor, de modo que el movimiento se lee en tres dimensiones.',
    'orient.click': 'Haga clic sobre la superficie para colocar al explorador',
    'cons.utility': 'Función de utilidad',
    'cons.cobb': 'Cobb–Douglas  x^a · y^(1−a)',
    'cons.ces': 'CES  (x^r + y^r)^(1/r)',
    'cons.subs': 'Sustitutos perfectos  a·x + (1−a)·y',
    'cons.quasi': 'Cuasilineal  a·ln x + y',
    'cons.alpha': 'Participación a',
    'cons.rho': 'Sustitución r',
    'cons.px': 'precio de x',
    'cons.py': 'precio de y',
    'cons.inc': 'ingreso',
    'cons.note': 'El conjunto factible pasa a ser el conjunto presupuestario p<sub>x</sub>·x + p<sub>y</sub>·y ≤ m con x, y ≥ 0, el dominio se encuadra sobre él y el vocabulario en pantalla cambia: las curvas de nivel son curvas de indiferencia y RMS es la relación marginal de sustitución. Active el óptimo para encontrar la elección del consumidor.',
    'cons.contours': 'Curvas de indiferencia',
    'cons.curveshow': 'Curva de indiferencia sobre la que está parado',
    'cons.seccurve': 'La curva de indiferencia bajo sus pies',
    'cons.mrs': 'TMS',
    'cons.mrshelp': 'Tasa marginal de sustitución — |∂u/∂x ÷ ∂u/∂y|, el valor absoluto de la pendiente de la curva de indiferencia en la canasta donde está parado. En el óptimo iguala la razón de precios p_x / p_y.',
    'cons.budget': 'Conjunto presupuestario',
    'lab.sec': 'Panel del mapa plano',
    'lab.link': 'Abrir el Laboratorio — el mismo programa con un panel de mapa plano junto a la escena',
    'lab.linkback': 'Volver a la presentación clásica',
    'lab.mode': 'Qué muestra el panel',
    'lab.ramp': 'Mapa de calor con la rampa de las curvas de nivel',
    'lab.heat': 'Mapa de calor clásico',
    'lab.down': 'Vista cenital de la superficie',
    'lab.off': 'Nada — ocultar el panel',
    'lab.opacity': 'Opacidad del panel',
    'lab.size': 'Tamaño del panel',
    'lab.full': 'Pantalla completa',
    'lab.projlabel': 'el plano (x, y)',
    'lab.note': 'El panel es la figura que dibuja su libro de texto: el dominio visto desde arriba, con las mismas curvas de nivel en los mismos colores, la misma recta tangente y el explorador como un punto. Todo lo que hay en él es el mismo estado de la escena de atrás: camine en la vista 3D y el punto camina sobre el mapa.',
    'sec.domain': 'Dominio',
    'dom.xmin': 'x mín', 'dom.xmax': 'x máx', 'dom.ymin': 'y mín', 'dom.ymax': 'y máx',
    'dom.res': 'Resolución de la malla',
    'dom.axes': 'Escala de los ejes',
    'dom.sx': 'eje x', 'dom.sy': 'eje y', 'dom.sz': 'eje z (inclinación)',
    'dom.isotropic': 'Volver a ejes iguales',
    'dom.axesnote': 'Los tres en 1 es el espacio cartesiano corriente, donde la esfera unitaria es redonda. Estirar un eje cambia solo la imagen: todos los números reportados siguen siendo los verdaderos.',
    'dom.follow': 'La ventana sigue al explorador',
    'dom.followg': 'paso G (x)',
    'dom.followh': 'paso H (y)',
    'dom.follownote': 'Al llegar a un borde, ese eje se desplaza G (u H) veces su propia anchura en la direcci\u00f3n en que iba caminando, y el terreno se reconstruye alrededor de la nueva ventana. La anchura no cambia, de modo que la escala —y con ella toda medida tomada contra el explorador de 1,80 m— sobrevive al desplazamiento. Queda desactivada en el problema del consumidor, donde el dominio no es una ventana sino el conjunto de cestas que existen.',
    'dom.rebuild': 'Reconstruir el terreno',

    'sec.feasible': 'Conjunto factible',
    'feas.label': 'restricciones',
    'feas.examples': '— ejemplos —',
    'feas.triangle': 'Triángulo  x,y ≥ 0, x+y ≤ 2',
    'feas.disc': 'Disco  x² + y² ≤ 1',
    'feas.rect': 'Rectángulo',
    'feas.two': 'Dos rectas de presupuesto',
    'feas.curved': 'x·y ≥ 0.3, x+y ≤ 2.5',
    'feas.walls': 'Mostrar los muros de la frontera',
    'feas.isolate': 'Volver translúcido lo que está afuera',

    'sec.map': 'Mapa y terreno',
    'sec.grid': 'Ret\u00edcula sobre la superficie',
    'sec.scale': 'Escala del explorador',
    'map.contours': 'Curvas de nivel',
    'map.cstep': 'Intervalo entre curvas Δz (vacío = automático)',
    'map.cwidth': 'Ancho del sendero',
    'map.cwidthnote': 'Se mide en alturas del explorador, para que los senderos sigan siendo transitables a cualquier escala: si encoge al explorador, las curvas se estrechan con él. Dos alturas es el mismo ancho que el lado de un cuadrado de la rejilla.',
    'map.heightcol': 'Colorear la superficie según la altura',
    'map.world': 'Pintar encima el mapamundi',
    'map.worldnote': 'Longitud en horizontal, latitud en vertical: el mapa más plano que hay, colocado sobre el rectángulo de parámetros, sobre el dominio de una gráfica, o sobre la longitud y la latitud respecto del centro de una superficie implícita. En la esfera estándar vuelve a ser el globo del que se trazó y la distorsión del mapa plano se deshace a la vista. En cualquier otra se deforma a la manera de esa superficie. Ninguna hoja de papel puede llevar una esfera sin estirarla: eso es el Teorema Egregio de Gauss, y así se ve.',
    'map.grid': 'Ret\u00edcula de coordenadas sobre la superficie',
    'map.gridnote': 'Cada cuadrado mide dos exploradores de lado, medido sobre la superficie, en los tres reg\u00edmenes, de modo que la malla es una regla y no un adorno. En una gr\u00e1fica es la ret\u00edcula del plano (x, y) levantada sobre la superficie; en una param\u00e9trica, sus l\u00edneas de par\u00e1metro; en una impl\u00edcita, donde la superficie corta los planos coordenados. Se dibuja por ambos lados, de modo que sigue siendo legible desde dentro.',
    'map.geogrid': 'Construirla con geod\u00e9sicas',
    'map.geonote': 'La ret\u00edcula geod\u00e9sica se construye solo con caminos rect\u00edsimos y longitud de arco, as\u00ed que sus cuadrados miden de verdad ese tama\u00f1o est\u00e9n donde est\u00e9n, cosa que las otras dos no pueden prometer, porque su espaciado viene de c\u00f3mo se escribi\u00f3 la superficie y no de la superficie. Donde los cuadrados dejan de cortarse en \u00e1ngulo recto, eso es la curvatura.',
    'map.gridside': 'cuadrados de {n} alturas de explorador de lado{m}',
    'map.gridgeo': 'cuadrados geod\u00e9sicos de {n} alturas de explorador de arco por lado',
    'map.clamped': 'se amplió el intervalo para no generar demasiadas curvas',
    'map.decor': 'Vegetación, rocas y nieve',
    'map.water': 'Agua en las depresiones',
    'map.density': 'Densidad de la decoración',
    'map.decorsize': 'Tamaño de los árboles',
    'map.decorsizenote': 'A 1× un árbol mide unas cuatro veces la altura del explorador, que es lo que mide un árbol. En una esfera pequeña eso da un bosque altísimo, así que este mando está aquí para bajarlo.',
    'map.decormatch': 'La vegetación se escala con el explorador',
    'map.decormatchnote': 'Activado por defecto: encoja o agrande al explorador con el mando de escala y cada árbol, roca y brizna de hierba encoge o crece exactamente en el mismo factor, así que la imagen conserva las mismas proporciones a cualquier escala. El mando de arriba sigue multiplicando por encima de esto. Desactívelo para mantener la vegetación en un tamaño fijo mientras la escala del propio explorador cambia por debajo.',
    'map.shadows': 'Sombras (cuesta rendimiento)',

    'sec.deriv': 'Derivadas',
    'deriv.disc': 'Resaltar la vecindad',
    'deriv.radius': 'Radio',
    'deriv.dx': 'Flecha ∂f/∂x',
    'deriv.dy': 'Flecha ∂f/∂y',
    'deriv.grad': 'Gradiente ∇f',
    'deriv.dir': 'Derivada direccional',
    'deriv.dirnote': 'Mueva el ratón para girar <b>u</b> sobre el borde; mantenga el botón <b>derecho</b> del ratón para mirar alrededor. Se puede seguir caminando.',
    'deriv.arcnote': 'El radio se mide como longitud de arco: la distancia realmente recorrida sobre la superficie, no sobre el suelo plano de abajo. En una ladera empinada el entorno abarca menos del plano (x, y) y su borde deja de ser una circunferencia.',
    'deriv.tangent': 'Plano tangente',
    'deriv.geodisc': 'Medirla con geodésicas',
    'deriv.geodiscnote': 'El borde pasa a ser el conjunto de puntos a esa distancia caminando por el camino más recto, en vez de siguiendo un rumbo fijo de brújula. Ambos coinciden en un plano y en ningún otro sitio: lo que se separan es la curvatura.',
    'deriv.geocircle': 'Círculo geodésico a su alrededor',
    'deriv.axisa': 'Primera dirección coordenada',
    'deriv.axisb': 'Segunda dirección coordenada',
    'deriv.velocity': 'Vector velocidad',
    'deriv.tangentp': 'Plano tangente a sus pies',
    'deriv.intrinsic': 'Aquí no hay f, así que no hay función de la que tomar una derivada parcial: lo que queda son los objetos de la propia superficie. La vecindad es el círculo geodésico, todo lo que se alcanza caminando esa distancia por el camino más recto. Las dos flechas son las direcciones coordenadas de la rejilla que esté activada, tangentes a la superficie. La velocidad es la dirección en la que se desplaza de verdad.',

    'sec.curve': 'La curva bajo sus pies',
    'curve.show': 'Curva de nivel sobre la que está parado',
    'curve.tangent': 'Recta tangente a esa curva',
    'curve.note': 'Ambas se dibujan sobre la propia superficie y siguen al explorador continuamente. La tangente es la dirección tangente proyectada de vuelta sobre la superficie, así que se pega al terreno; se separa de la curva de nivel solo en segundo orden, y al encoger al explorador esa separación desaparece. Cada curva toma su color de su propia altura en la rampa.',

    'sec.zoom': 'Plano tangente',
    'zoom.scale': 'Escala del explorador',
    'zoom.note': 'Act\u00edvelo y baje una o dos d\u00e9cadas la escala del explorador: una superficie diferenciable se vuelve indistinguible de su plano tangente, que es lo que significa diferenciable.',
    'zoom.scalenote': 'Deslice a la derecha y el explorador encoge, hasta 0,18 mm; deslice a la izquierda y crece hasta cien veces su tama\u00f1o natural. La rueda del rat\u00f3n con \u2318/\u229e o Alt pulsado hace lo mismo. Todo lo que se mide contra \u00e9l —el entorno, las flechas, los cuadrados de la ret\u00edcula— cambia con \u00e9l, y eso es lo que hace de esto una regla y no un control de c\u00e1mara.',

    'sec.opt': 'Optimización',
    'opt.show': 'Mostrar el óptimo',
    'opt.idle': 'Maximizar f sobre el conjunto factible.',
    'opt.goto': 'Teletransportarse al óptimo',
    'opt.none': 'No se encontró ningún punto factible en este dominio.',
    'opt.max': 'máx f =',
    'opt.at': 'en (x, y) =',
    'opt.on': 'en',
    'opt.interior': 'el interior del conjunto factible',
    'opt.boundary': 'la frontera del conjunto factible',
    'opt.domain': 'el dominio',
    'opt.gradthere': '‖∇f‖ allí =',
    'opt.pill': 'máx {v} en ({x}, {y})',

    'sec.view': 'Vista',
    'view.first': 'Primera persona',
    'view.third': 'Tercera persona',
    'view.drone': 'Dron',
    'view.dronecam': 'Cámara del dron',
    'view.dronefirst': 'Primera persona — desde el dron',
    'view.dronethird': 'Tercera persona — detrás del dron',
    'view.dronenote': 'El dron vuela nivelado: W A S D lo desplazan sobre el plano (x, y), Espacio y Ctrl fijan su altitud, y el ratón solo apunta la cámara. El haz que cuelga de él cae perpendicular al plano z = 0 y marca el punto del dominio sobre el que está.',
    'view.style': 'Aspecto del explorador',
    'view.speed': 'Velocidad al caminar',
    'view.padoff': 'Sin mando: pulse un botón de uno para despertarlo.',
    'view.padon': 'Mando: {name}',
    'view.padinvert': 'Invertir el arriba / abajo del stick derecho',
    'view.padnote': 'Un mando con distribución de Xbox funciona sin más, también en un iPhone o iPad por Bluetooth y sin instalar ninguna aplicación. El stick izquierdo camina y se desplaza de lado; el derecho mira y gira. RT esprinta; LB y RB bajan y suben el dron. A recorre las tres vistas, B la vecindad, X la rejilla, Y el mapamundi y Start oculta el panel; arriba y abajo de la cruceta cambian la escala del explorador, e izquierda y derecha el zoom de la cámara. Los navegadores mantienen oculto un mando hasta que se pulsa un botón, así que si la línea de arriba dice que no hay ninguno, pulse uno.',
    'view.speednote': 'Un múltiplo del paso normal, que ya se mide en alturas del explorador por segundo: un explorador diez veces más pequeño recorre el mismo terreno en el mismo tiempo. Mantenga Mayús para esprintar por encima de lo que fije aquí.',
    'style.explorer': 'Excursionista',
    'style.brick': 'Figura de bloques',
    'style.blocky': 'Estilo píxel',
    'style.buddy': 'Amigo redondo',
    'view.compass': 'Indicador de direcci\u00f3n',
    'view.compassnote': 'El globo de la esquina superior derecha muestra hacia d\u00f3nde est\u00e1 mirando: latitud y longitud alrededor de una figurita orientada en la misma direcci\u00f3n, con el rumbo y la elevaci\u00f3n debajo. Mantenga \u2318/\u229e o Alt, o pulse Esc y mueva el rat\u00f3n, y se agranda.',
    'view.holdkey': 'Tecla que se mantiene para mirar',
    'hold.either': 'Cualquiera — Alt/\u2325 o \u2318/\u229e',
    'hold.alt': 'Solo Alt / \u2325 Option',
    'hold.meta': 'Solo \u2318 Comando / \u229e Windows',
    'hold.note': 'Mantenida pulsada, esta tecla convierte W A S D y las flechas en un control de mirada, y la rueda del rat\u00f3n en el tama\u00f1o del explorador. Tenga en cuenta que \u2318+W cierra una pesta\u00f1a en un Mac y ninguna p\u00e1gina web puede impedirlo, y que Windows se reserva \u229e+flechas para ajustar ventanas: elija Alt / \u2325 arriba y no le afecta ninguna de las dos cosas.',
    'hold.notealt': 'Mantenida pulsada, esta tecla convierte W A S D y las flechas en un control de mirada, y la rueda del rat\u00f3n en el tama\u00f1o del explorador. Alt / \u2325 est\u00e1 libre con todas las teclas en todas las plataformas, as\u00ed que aqu\u00ed el sistema operativo no se queda con nada antes.',
    'view.top': 'Mirar desde arriba',
    'view.reset': 'Volver al centro',

    'sec.help': 'Ayuda',
    'help.move': 'Moverse', 'help.run': 'correr', 'help.look': 'mirar', 'help.mouse': 'ratón',
    'help.keylook': 'Mirar sin el rat\u00f3n',
    'help.orcmd': 'o \u2318/\u229e',
    'help.zoomcam': 'Zoom de la c\u00e1mara',
    'help.zoomsize': 'tama\u00f1o del explorador',
    'help.wheel': 'rueda',
    'help.updown': 'Dron sube/baja',
    'help.release': 'Soltar el ratón', 'help.hide': 'ocultar este panel',
    'help.modnote': 'La tecla modificadora se <b>mantiene pulsada</b>, no se pulsa y suelta: el control de la mirada dura exactamente lo que dura la pulsaci\u00f3n. Sirve cualquiera de <kbd>Alt</kbd>/<kbd>\u2325</kbd>, <kbd>\u2318</kbd> o <kbd>\u229e</kbd>; pero tenga en cuenta que en un Mac <kbd>\u2318</kbd>+<kbd>W</kbd> cierra la pesta\u00f1a y ninguna p\u00e1gina web puede impedirlo, as\u00ed que use <kbd>\u2325</kbd> si quiere W A S D ah\u00ed; y Windows se reserva <kbd>\u229e</kbd>+flechas, de modo que all\u00ed conviene <kbd>Alt</kbd> o W A S D.',
    'help.syntax': 'Escriba funciones con <code>+ − * / ^</code> y <code>sin cos tan exp ln sqrt abs min max hypot gauss</code>. El producto implícito funciona: <code>2x</code>, <code>x y</code>. Las restricciones se combinan con <code>&&</code>, <code>||</code> y comparaciones encadenadas como <code>0&lt;=x&lt;=1</code>.',

    'hud.z': 'z = f(x,y)',
    'hud.avg': 'prom',
    'hud.scale11': 'escala 1 : 1',
    'hud.tall': 'explorador de {h} m',
    'hud.uat': 'u a {deg}°',
    'hud.angle': 'se cortan a',
    'hud.noaxis': 'perpendicular a la superficie aquí: no hay dirección que dibujar',
    'hud.frombase': '{deg} desde {a}',
    'hud.undefined': 'indefinida',
    'hud.rmshelp': 'RMS — |∂f/∂x ÷ ∂f/∂y|, el valor absoluto de la pendiente de la curva de nivel en el punto donde está parado.',

    'dial.camhelp': 'Zoom de la cámara — la rueda del ratón, o un gesto de pellizco en el trackpad. Acerca la cámara; el explorador conserva exactamente su tamaño.',
    'dial.camreset': 'Volver a la distancia normal de la cámara',
    'dial.sizehelp': 'Tamaño del explorador — mantenga ⌘ (⊞ en Windows) o Alt/Option y use la rueda. Al encogerlo se amplía la superficie, igual que el dial de la regla en el panel.',
    'dial.sizereset': 'Volver a 1 : 1 — el explorador de 1,8 m',

    'cc.click': 'Haga clic para mirar alrededor',
    'cc.esc': 'Esc suelta el ratón',
    'loading': 'Construyendo el terreno…',

    'msg.undefinedFrac': 'f no está definida en el {pct}% del dominio',
    'msg.emptyFeasible': 'el conjunto factible está vacío aquí',
    'surf.empty': 'Esa superficie está vacía en esta caja: amplíe los límites o revise la fórmula.',
    'err.emptyDomain': 'El dominio está vacío: verifique que x máx > x mín y que y máx > y mín.',
    'err.undefinedEverywhere': 'f(x,y) no está definida en ningún punto de este dominio.',
    'err.at': '(en el carácter {pos})',

    'p.badChar': 'Carácter inesperado «{c}»',
    'p.unknownFn': 'Función desconocida «{name}»',
    'p.missingParen': 'Falta un «)»',
    'p.missingBar': 'Falta la barra «|» de cierre',
    'p.missingCall': 'Falta un «)» después de {name}(',
    'p.arity': '{name}() recibe {want} argumento(s), se dieron {got}',
    'p.isFunction': '«{name}» es una función: escriba {name}(...)',
    'p.unknownName': 'Nombre desconocido «{name}»',
    'p.badOperator': 'Operador inesperado «{op}»',
    'p.eof': 'La expresión termina antes de tiempo',
    'p.unexpected': 'Elemento inesperado «{what}»',
    'p.trailing': 'Sobra texto al final de la expresión',
    'p.empty': 'La expresión está vacía',
    'p.notNumber': 'La expresión no produjo un número',
  },
};

const STORAGE_KEY = 'gradient-peaks-lang';
let current = 'en';
const listeners = [];

function supported(code) {
  return LANGUAGES.some((l) => l.code === code) ? code : null;
}

/** ?lang= wins, then the last explicit choice, then the browser. */
export function detectLanguage() {
  try {
    const fromUrl = supported(new URLSearchParams(location.search).get('lang'));
    if (fromUrl) return fromUrl;
  } catch (err) { /* no URL to read */ }

  try {
    const saved = supported(localStorage.getItem(STORAGE_KEY));
    if (saved) return saved;
  } catch (err) { /* storage blocked */ }

  const nav = (navigator.languages && navigator.languages[0]) || navigator.language || 'en';
  return supported(String(nav).slice(0, 2).toLowerCase()) || 'en';
}

export function getLanguage() { return current; }

export function setLanguage(code) {
  current = supported(code) || 'en';
  try { localStorage.setItem(STORAGE_KEY, current); } catch (err) { /* storage blocked */ }
  document.documentElement.lang = current;
  applyStatic();
  for (const fn of listeners) fn(current);
}

export function onLanguageChange(fn) { listeners.push(fn); }

/** Look up `key`, substituting {placeholders} from `params`. */
export function t(key, params) {
  const table = STRINGS[current] || STRINGS.en;
  let s = table[key];
  if (s === undefined) s = STRINGS.en[key];
  if (s === undefined) return key;
  if (!params) return s;
  return s.replace(/\{(\w+)\}/g, (m, name) => (params[name] === undefined ? m : params[name]));
}

/**
 * Translate the static markup.
 *   data-i18n       -> textContent
 *   data-i18n-html  -> innerHTML (for strings carrying <code> or <b>)
 *   data-i18n-title -> title attribute
 */
export function applyStatic(root) {
  const scope = root || document;

  for (const el of scope.querySelectorAll('[data-i18n]')) {
    el.textContent = t(el.getAttribute('data-i18n'));
  }
  for (const el of scope.querySelectorAll('[data-i18n-html]')) {
    el.innerHTML = t(el.getAttribute('data-i18n-html'));
  }
  for (const el of scope.querySelectorAll('[data-i18n-title]')) {
    el.title = t(el.getAttribute('data-i18n-title'));
  }

  if (scope === document) {
    // Two front ends share this dictionary, and they are different pages. A
    // page that names its own title key keeps it; only the one that says
    // nothing gets the default. Otherwise the Lab's tab is indistinguishable
    // from the classic app's, which is exactly when you have both open.
    const key = document.documentElement.dataset.titleKey || 'meta.title';
    document.title = t(key);
    const desc = document.querySelector('meta[name="description"]');
    if (desc) desc.content = t(document.documentElement.dataset.descKey || 'meta.description');
  }
}
